#!/sbin/sh

# Find current slot
slot="$(getprop ro.boot.slot_suffix)"
if [ -z "$slot" ]; then
  slot=_a
fi

# Preferentially use the backup matching the slot
src="/sdcard/Fox/BACKUPS/init_boot_backup${slot}.img"

# But if that doesn't exist, use the other slot's backup if it exists
if [ ! -f "$src" ]; then
    # Try the other slot
    if [ "$slot" = "_a" ]; then
        alt_src="/sdcard/Fox/BACKUPS/init_boot_backup_b.img"
    else
        alt_src="/sdcard/Fox/BACKUPS/init_boot_backup_a.img"
    fi
    if [ -f "$alt_src" ]; then
        src="$alt_src"
    else
        echo "Error: No suitable backup file found on /sdcard!"
        exit 1
    fi
fi

dst="/dev/block/by-name/init_boot${slot}"

if [ ! -e "$dst" ]; then
    echo "Error: Partition $dst not found!"
    exit 1
fi

echo "Restoring $src to $dst ..."
/system/bin/dd if="$src" of="$dst"
if [ $? -ne 0 ]; then
    echo "Error: Restore failed!"
    exit 1
fi
echo "Restore complete!"
exit 0
