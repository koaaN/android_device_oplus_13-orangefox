#!/sbin/sh

# === Kernel Version Check ===
KERNEL_VERSION=$(/system/bin/uname -r 2>/dev/null)
echo "$KERNEL_VERSION" | grep '^6\.6\.' > /dev/null
if [ $? -ne 0 ]; then
    echo "Error: Incompatible kernel! Only 6.6.x kernels supported."
    exit 1
fi
echo "Kernel version OK: $KERNEL_VERSION"

# === Detect Slot ===
slot="$(getprop ro.boot.slot_suffix)"
if [ -z "$slot" ]; then
  # fallback for some devices (assume _a)
  slot=_a
fi

src="/dev/block/by-name/init_boot${slot}"
dst="/sdcard/Fox/BACKUPS/init_boot_backup${slot}.img"

# === Backup init_boot Partition ===
if [ -e "$src" ]; then
    echo "Backing up $src to $dst"
    /system/bin/dd if="$src" of="$dst"
    if [ $? -ne 0 ]; then
        echo "Error: Backup failed!"
        exit 1
    fi
    echo "Backup complete!"
    exit 0
else
    echo "Partition $src not found!"
    exit 1
fi
